const express = require('express');
const app = express();
const productRouter = require('./routes/product');

app.use(express.json()); // Enable JSON parsing for request bodies
app.use(express.urlencoded({ extended: true })); // Enable URL-encoded parsing for request bodies

app.use('/products', productRouter); // Assuming you want to prefix your API endpoints with '/products'

app.listen(3000, () => {
  console.log('Server listening on port 3000');
});
