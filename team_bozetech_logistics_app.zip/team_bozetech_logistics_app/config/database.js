const env = process.env.NODE_ENV || 'development';

const databaseConfig = {
  [env]: {
    username: 'team_bozetech_logistics_app',
    password: `${'Mycc0001!'}`, // Use template literals to ensure the password is a string
    database: 'team_bozetech_logistics_app',
    host: 'localhost',
    dialect: 'postgres',
  },
  development: {
    // Override or add development-specific settings here
  },
  production: {
    // Override or add production-specific settings here
  },
};

console.log(typeof databaseConfig[env].password); // Add this line

module.exports = databaseConfig;
