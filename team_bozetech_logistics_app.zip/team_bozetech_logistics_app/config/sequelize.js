const { Sequelize } = require('sequelize');
const databaseConfig = require('./database');

const sequelize = new Sequelize(
  databaseConfig[process.env.NODE_ENV || 'development'].database,
  databaseConfig[process.env.NODE_ENV || 'development'].username,
  databaseConfig[process.env.NODE_ENV || 'development'].password, {
    host: databaseConfig[process.env.NODE_ENV || 'development'].host,
    dialect: 'postgres', // Explicitly specify the dialect
    logging: false, // Set to true for debugging
  }
);

module.exports = sequelize;
