const { Sequelize } = require('sequelize');

const sequelize = new Sequelize('team_bozetech_logistics_app', 'team_bozetech_logistics_app_user', 'Mycc0001!', {
  host: 'localhost',
  dialect: 'postgres',
});

module.exports = sequelize;
